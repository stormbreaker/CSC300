3-28-15
CSC 300 Data Structures
Benjamin Kaiser
Leif Torgersen

The contained documents are the combined testing documents for Leif Torgersen and Benjamin Kaiser's Assignment 2 for CSC 300 Data Structures.  

Files following the format llnr.txt contain the input values
Files following the format lnrOut or rlrexpout.txt contain the expected results which are human readable.
Files following the format rrrTree.txt contain the tree in a human readable format with point information.
